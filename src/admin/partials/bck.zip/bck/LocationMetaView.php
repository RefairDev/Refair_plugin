<?php
Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;

class LocationMetaView extends MetaView{

	public static $type = "location";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    protected function script()
    {
        ?>
            <script type="text/javascript">
    
                var moduleLOC = (function($){
    
                    var API_KEY = "AIzaSyDlBV0xY6Bse-0qCoHQUQKgLoYNt0yXDiQ";
    
                    var $lat = $('[name="<?php echo $this->name; ?>[lat]"]');
                    var $lng = $('[name="<?php echo $this->name; ?>[lng]"]');
                    var $location = $('[name="<?php echo $this->name; ?>[location]"]');
    
                    return function(e) {
    
                        e.preventDefault();
    
                        var value = $(this).prev().val();
    
                        jQuery.ajax({
                            url: 'https://maps.googleapis.com/maps/api/geocode/json?address=' + encodeURI(value) + '&key=' + API_KEY,
                            success: function(resp) {
                                var result = resp.results[0];
                                var address = result.formatted_address;
    
                                var location = result.geometry.location;
    
                                $lat.val(location.lat);
                                $lng.val(location.lng);
    
                                $location.val(address);
                            }
                        });
    
                    }
    
                })(jQuery);
    
                jQuery('#search').on('click', moduleLOC)
                
    
                /*jQuery.ajax({
                    url: 'https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=' + API_KEY,
                    success: function(resp) {
                        console.log(resp)
                    }
                })*/
            </script>
        <?php
    }

    public function get_view($value,$data){
        ?>
        <p>
            <input type="text" name="<?php echo $this->name; ?>[location]" id="<?php echo $this->name; ?>[location]" class="meta-video regular-text" value="<?php echo $meta['location']; ?>"/>
            <button id="search">Search</button>

        </p>
        <p>
            <input type="text" name="<?php echo $this->name; ?>[lat]" id="<?php echo $this->name; ?>[lat]" class="meta-video regular-text" value="<?php echo $meta['lat']; ?>"/>

            <input type="text" name="<?php echo $this->name; ?>[lng]" id="<?php echo $this->name; ?>[lng]" class="meta-video regular-text" value="<?php echo $meta['lng']; ?>"/>
        </p>
        <?php
        $this->script();
    }
}