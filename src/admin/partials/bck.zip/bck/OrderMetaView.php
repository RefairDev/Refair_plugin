<?php

Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;
Class OrderMetaView extends InputMetaView{

    public static $type = "order";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
        $this->set_type("number");
    }
}