<?php
Namespace PixelscodexPlugin\Metas\Views;

use PixelscodexPlugin\MetaView;

class LocMapMetaView extends MetaView{

	public static $type = "locmap";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
	}
	
	protected function script($apikey, $name,$uniqid)
    {
        ?>
    	<style>
            #<?php echo $name; ?>-<?php echo $uniqid; ?>-map{
                height: 350px;
                width: 400px;
            }
            p>label + input{
            margin-left:7px;
            }
            .ui-dialog.location-result{
                z-index:900;
            }
        </style>
    	<script type="text/javascript">

    		var moduleLOCMAP_<?php echo $uniqid; ?> = (function($){

    			var $lat = $('[name="<?php echo $name; ?>[lat]"]');
    			var $lng = $('[name="<?php echo $name; ?>[lng]"]');
    			var $location = $('[name="<?php echo $name; ?>[location]"]');
    			var locationResults=[];
    			var resultsDialog={};
    			var map={};
    			var mapDefaultCenter = [44.8368, -0.5896];
    			var mapDefaultZoom = 11;
    			var locMarker={};

    			this.selectLocationResult = jQuery.proxy(this.selectLocationResult,this);

    			return {

    				init: function(){
			    		jQuery('#search-<?php echo $uniqid; ?>').on('click', moduleLOCMAP_<?php echo $uniqid; ?>.manageSearchClick)
			    		
						resultsDialog = jQuery(".<?php echo $name; ?>-location-results-dialog").dialog({
							autoOpen : false,
							title: "Choisissez votre résultat",
							dialogClass: "no-close location-result",
							buttons: [{
								text: "Valider",
								click: function() {
									moduleLOCMAP_<?php echo $uniqid; ?>.selectLocationResult();
							        $( this ).dialog( "close" );
							      }
						      }],
						});

						let initCenter=[0,0];
						if ($lat.val() != "" && $lng.val() !=""){
							let locLat = parseFloat($lat.val());
							let locLng = parseFloat($lng.val());
							initCenter=[locLat,locLng];
						}else{
							initCenter = mapDefaultCenter;
						}


						map = L.map("<?php echo $name; ?>-<?php echo $uniqid; ?>-map", {center:initCenter, zoom:mapDefaultZoom  });
						L.tileLayer('https://a.tile.openstreetmap.org/{z}/{x}/{y}.png', {
						    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
						}).addTo(map);

						if ( $lat.val() != "" && $lng.val() !=""){
							this.locMarker = L.marker([$lat.val(),$lng.val()]).addTo(map);
						}
						map.on("click",this.manageClickEvent,this);

					},

    				manageSearchClick: function(e){
	    				
    					e.preventDefault();

    					var value = $(this).prev().val();
    					
	    				jQuery.ajax({
							url: "https://maps.googleapis.com/maps/api/geocode/json?address="+value+"&language=fr&region=fr&key=<?php echo $apikey;?>",
							success: function(resp) {
								if(! resultsDialog.dialog( "isOpen" )){
									switch(resp.status)
									{
    									case "OK":
    									{
        									locationResults = resp.results;
        
        									locationResults.forEach(function(valeurCourante,index ,resultArray){
        										jQuery(".<?php echo $name;?>-result-list").append('<li class="location-result"><input type="radio" name="<?php echo $name; ?>-location-choice" value="'+ index +'">'+ valeurCourante.formatted_address +'</li>');	
        									});
        									resultsDialog.dialog( "open" );
        									break;
    									}
    									case"ZERO_RESULTS":
    									{
    										alert("No result returned, correct and renew your request"); 
    										break;
    									}
    									default:
    									{
    										alert('Error: Google geocode returned "'+ resp.status +'"' );
    										
    									}
									}
								}
							}
						});
	    			},

    				selectLocationResult: function(){
	    				var resultValue = jQuery("[name='<?php echo $name; ?>-location-choice']").val();

	    				this.placeMarker(locationResults[resultValue].geometry.location.lat,locationResults[resultValue].geometry.location.lng);

	    				if(jQuery("[name='keep-label-<?php echo $uniqid; ?>']").prop("checked")!==true){
	    					$location.val(locationResults[resultValue].formatted_address);
	    				}
	    				
	    				jQuery(".<?php echo $name;?>-result-list").empty();
	    				resultsDialog.dialog("close");
	    			},

	    			manageClickEvent: function(e){
	    				this.placeMarker(e.latlng.lat,e.latlng.lng);
	    			},
	    			placeMarker: function(lat,lng){

	    				if (this.locMarker instanceof L.Marker){
	    					this.locMarker.removeFrom(map);
	    				}
	    				this.locMarker = L.marker([lat,lng]).addTo(map);
	    				$lat.val(lat);
	    				$lng.val(lng);
	    			}
	    			
	    			

    			} 			
	    			

    		})(jQuery);


			window.onload=()=>{
				moduleLOCMAP_<?php echo $uniqid; ?>.init();
			};

			
    		/*jQuery.ajax({
    			url: 'https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=' + API_KEY,
    			success: function(resp) {
    				console.log(resp)
    			}
    		})*/
    	</script>
    	<?php
    }

    public function get_view($value,$data){

		$uniqid=uniqid ();
		$location = "";
		$lat= "";
		$lng= "";

		if (!empty($value) && is_array($value)){
			if(array_key_exists('location', $value)){$location = $value['location'];}
			if(array_key_exists('lat', $value)){$lat= $value['lat'];} 
			if(array_key_exists('lng', $value)){$lng= $value['lng'];}
		}

		ob_start();
		?>
		<p>
			<label for="<?php echo $data['name']; ?>[location]">Adresse</label><input type="text" name="<?php echo $data['name']; ?>[location]" id="<?php echo $data['name']; ?>[location]" class="meta-video regular-text" value="<?php echo $location; ?>"/>
			<button id="search-<?php echo $uniqid; ?>">Search</button>
		</p>
		<p>
			<label for="<?php echo $data['name']; ?>[lat]">Latitude</label><input type="text" name="<?php echo $data['name']; ?>[lat]" id="<?php echo $data['name']; ?>[lat]" class="meta-video regular-text" value="<?php echo $lat; ?>"/>
			<label for="<?php echo $data['name']; ?>[lng]">Longitude</label><input type="text" name="<?php echo $data['name']; ?>[lng]" id="<?php echo $data['name']; ?>[lng]" class="meta-video regular-text" value="<?php echo $lng; ?>"/>
		</p>
		<div class="clearfix">
			<div id="<?php echo $data['name']; ?>-<?php echo $uniqid; ?>-map">
			
			</div>
		</div>
		<div class="<?php echo $data['name']; ?>-location-results-dialog">
		<ul class="<?php echo $data['name']; ?>-result-list">   		
		</ul>
		<input id="keep-label-<?php echo $uniqid; ?>" type="checkbox" name="keep-label-<?php echo $uniqid; ?>" value="keep_label"><label for="keep-label-<?php echo $uniqid; ?>">Garder la description</label>
		</div>
		<?php

		$this->script("AIzaSyBiGKE6Tra9w5NiNXUJ3unOyMZpTAsB7Zw",$data['name'], $uniqid);
		return ob_get_clean();
	}
}