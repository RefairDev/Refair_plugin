<?php

Namespace PixelscodexPlugin\Metas\Views;

use PixelscodexPlugin\MetaView;
use PixelscodexPlugin\Metas\Utils;

Class GroupMetaView extends MetaView{

    public static $type = "group";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data){

        $groupview="";
        if(isset($value) && array_key_exists($meta->name, $value)){$meta_value = $value[$meta->name];}else{ $meta_value = "";}
        foreach($data['options']['metas'] as $meta){
            $view_content = apply_filters("rveplugin_renderview_".$meta->type, $meta_value, array('name'=> $data['name'].'["'.$meta->name.'"]', 'description'=> $meta->title, "options"=> $meta->options));
            $view_content = apply_filters("rveplugin_wrapmeta_with_title", $view_content, $meta->title);
            $groupview .= $view_content;
        }
        return $groupview;
    }
}