<?php
Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;

class ImageMetaView extends MetaView{

    public static $type = "image";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    static public function url_img($src) {
        $url = wp_parse_url($src);
        $site_url = wp_parse_url(get_site_url());

        return trim($site_url['scheme'] . '://' . $site_url['host'] . $url['path']);
    }


    public function get_view($value,$data){
        

        if (array_key_exists("options",$data ) && array_key_exists("size",$data["options"] ) && $data["options"]["size"] > 1): 
            for ($i=0; $i < $this->size; $i++) { 
                if (is_array($value[$i])){
                    $value_url = $value['url'];
                    $value_id = $value['id'];
                }else{
                    $value_url = $value[$i];
                    $value_id = attachment_url_to_postid($value[$i]);
                }
            ?>
                <p>
                <input type="hidden" name="<?php echo "{$data['name']}[{$i}][url]"; ?>" id="<?php echo "{$data['name']}-$i-url"; ?>" class="meta-url regular-text" value="<?php echo $value_url; ?>"/>
                    <input type="hidden" name="<?php echo "{$data['name']}[{$i}][id]"; ?>" id="<?php echo "{$data['name']}-$i-id"; ?>" class="meta-id regular-text" value="<?php echo $value_id; ?>"/>
                    <input type="button" class="button browse-image" value="Browse"/>
                </p>
                <div class="video-preview">
                    <?php if (isset($value_url)):
                        $img_src = $this->url_img($value_url);
                        ?>

                        <?php echo ($i + 1) . '. '; ?><img style="max-width: 250px; box-shadow: 1px 2px 4px 0 #324664" src="<?php echo $img_src; ?>">
                    <?php endif ?>
                </div>
                <script type="text/javascript">
                    function imageScript(){
                        setBrowseImgHandling();
                    }
                </script>
            <?php
            }

        else: 
            if (is_array($value)){
                $value_url = $value['url'];
                $value_id = $value['id'];
            }else{
                $value_url = $value;
                $value_id = attachment_url_to_postid($value);
            }
        ?>
            <p>
                <input type="hidden" name="<?php echo $data['name']."[url]"; ?>" id="<?php echo $data['name'].'-url'; ?>" class="media-url regular-text" value="<?php echo $value_url; ?>"/>
                <input type="hidden" name="<?php echo $data['name']."[id]"; ?>" id="<?php echo $data['name'].'-id'; ?>" class="media-id regular-text" value="<?php echo $value_id; ?>"/>
                <input type="button" class="button browse-image" value="Browse"/>
            </p>
            <div class="image-preview">
                <?php if (isset($value)):
                    $img_src = $this->url_img($value_url);
                ?>
                    <img style="max-width: 250px; box-shadow: 1px 2px 4px 0 #324664" src="<?php echo $img_src; ?>">
                <?php endif ?>
            </div>
            
                <script type="text/javascript">
                    function imageScript(){
                        setBrowseImgHandling();
                    }
                </script>
        <?php endif;

        }
}

class ExtensiveImageMetaView  extends MetaView
{    
    public static $type = "extensible-images";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }
    
    static public function url_img($src) {
        $url = wp_parse_url($src);
        $site_url = wp_parse_url(get_site_url());
        
        return trim($site_url['scheme'] . '://' . $site_url['host'] . $url['path']);
    }
    
    
	public function get_view($value,$data) {
	    global $post; 
        if (is_array($value)){
            $value_count = count($value);
        }else{
            $value_count = 1;
        }
        ob_start();
    	    ?>            	
            <p>
                <label for="<?php echo $data['name'];?>-input-number"><?php ?></label><input id="<?php echo $data['name'];?>-input-number" type=number min=1 value="<?php echo $value_count;?>">
            </p>
            <div id="<?php echo $data['name'] . '_extensible_images'; ?>">
                <?php
                for ($idx=0; $idx < $value_count; $idx++):
                    $meta_value = array('url'=>'#', 'caption'=>"", 'id'=>0);
                    if (isset($value[$idx])){
                        $meta_value = array_merge($meta_value,$value[$idx]) ;
                    }
                ?>
                <div id="<?php echo $data['name'] . '[' . $idx . ']'; ?>">
                    <label for="<?php echo $data['name'] . '[' . $idx . '][key]'; ?>"><?php echo ($idx+1).'. '; ?></label>
                    <p>
                        <input type="hidden" name="<?php echo $data['name'] . '[' . $idx . '][url]'; ?>" id="<?php echo $data['name'] . '[' . $idx . '][url]'; ?>" class="meta-video regular-text" value="<?php echo $meta_value['url']; ?>"/>
                        <input type="hidden" name="<?php echo $data['name'] . '[' . $idx . '][id]'; ?>" id="<?php echo $data['name'] . '[' . $idx . '][id]'; ?>" class="media-id regular-text" value="<?php echo $meta_value['id']; ?>"/>
                        <input type="button" class="button video-upload" value="<?php _e('Browse','pixelscodex');?>"/>
                        <input type="text" name="<?php echo  $data['name'] . '[' . $idx . '][caption]'; ?>" id="<?php echo $data['name'] . '[' . $idx . '][caption]'; ?>" class="regular-text" value="<?php echo $meta_value['caption']; ?>"/>
                        <div class="video-preview">
        
                        <?php 
                        if ($meta_value['url']!="#"):
                            $img_src = $this->url_img($meta_value['url']);
                        ?>
                        <img style="max-width: 250px; box-shadow: 1px 2px 4px 0 #324664" src="<?php echo $img_src; ?>">
                        <?php endif ?>
                    </div>
                    </p>
        
                </div>         
                <?php endfor;?>
                
            </div>
        
            <script>
            
        
                function changeInputNumber(event){
        
                    var newInputNumber = event.target.value;
                    var inputBlock = document.getElementById("<?php echo $data['name'] . '_extensible_images'; ?>");
        
                    if(inputBlock.children.length < newInputNumber)
                    {
                        while (inputBlock.children.length < newInputNumber){
                            var newKey = inputBlock.firstElementChild.cloneNode(true);
                            var newKeyIdx = (parseInt(inputBlock.children.length)).toString();
                            newKey.id = newKey.id.replace("[0]","["+newKeyIdx+"]");
                            
                            changeNodesIdx(newKey, newKeyIdx);
                            inputBlock.appendChild(newKey);
                        }
                    
                    }else{
                        while (inputBlock.children.length > newInputNumber){
                            inputBlock.removeChild(inputBlock.lastElementChild);
                        }
                    }
        
                    setBrowseImgHandling();
        
                }
        
                function changeNodesIdx(newKey, newKeyIdx){
                    var children = newKey.childNodes;
                    for (var childIdx = 0; childIdx < children.length; childIdx++) {
                                if (children[childIdx].htmlFor){
                                    children[childIdx].htmlFor = children[childIdx].htmlFor.replace("[0]","["+newKeyIdx+"]");
                                    children[childIdx].innerText = children[childIdx].innerText.replace("1",(parseInt(newKeyIdx)+1));}
                                if (children[childIdx].id){children[childIdx].id = children[childIdx].id.replace("[0]","["+newKeyIdx+"]");}
                                if (children[childIdx].name){children[childIdx].name = children[childIdx].name.replace("[0]","["+newKeyIdx+"]");}
                                if (children[childIdx].childNodes){changeNodesIdx(children[childIdx], newKeyIdx);}
                            }
                }

                function updateEventHandling(){
                    var inputNumber = document.getElementById("<?php echo $data['name'];?>-input-number");
                    inputNumber.onchange = changeInputNumber;
                }
                
                updateEventHandling();
            </script>
            <?php
            return ob_get_clean();
    	}
    }   