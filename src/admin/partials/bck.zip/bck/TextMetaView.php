<?php

Namespace PixelscodexPlugin\Metas\Views;

use PixelscodexPlugin\MetaView;
require_once("InputMetaView.php");


class TextMetaView extends InputMetaView {

    public static $type = "text";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());   
        $this->set_type("text");
    }
}

class DateMetaView extends InputMetaView{

    public static $type = "date";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
        $this->set_type("date");
    }
}

class TimeMetaView extends InputMetaView{

    public static $type = "time";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
        $this->set_type("time");
    }
}


class EmailMetaView extends InputMetaView{

    public static $type = "mail";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
        $this->set_type("email");
    }
}

class LongTextMetaView extends MetaView
{

    public static $type = "long"; 

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data){
        ?>
        <p>
            <textarea style="max-width: 25em; min-height: 120px;" name="<?php echo $data['name']; ?>" id="<?php echo $data['name']; ?>" class="regular-text"><?php echo $value; ?></textarea>
        </p>
        <?php
    }
}

class MultiTextMetaView extends MetaView{

    public static $type = "multi-text";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data){
        for ($i=0; $i < $this->size; $i++){
            if (isset($meta[$i])){
              $meta_value = $meta[$i];
            }else{
              $meta_value = "";
            }
              ?>
                  <p>
                      <?php echo ($i+1).'. '; ?><input type="text" name="<?php echo $this->name . '[' . $i . ']'; ?>" id="<?php echo $this->name . '[' . $i . ']'; ?>" class="meta-video regular-text" value="<?php echo $meta_value; ?>"/>
                  </p>
              <?php
        }
    }
}


class ExtensibleTextMetaView extends MetaView {

    public static $type = "extensible-text";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data){

    ?>
    <p>
        <label for="<?php echo $name;?>-input-number"><?php ?></label><input id="<?php echo $name;?>-input-number" type=number min=1 value="<?php echo count($meta);?>">
    </p>
    <div id="<?php echo $name . '_extensible_text'; ?>">
        <?php
        for ($idx=0; $idx < count($meta); $idx++):
            if (isset($meta[$idx])){
                $meta_value = $meta[$idx];
            }else{
                $meta_value = "";
            }
        ?>
        <div id="<?php echo $name . '[' . $idx . ']'; ?>">
            <label for="<?php echo $name . '[' . $idx . ']'; ?>"><?php echo ($idx+1).'. '; ?></label>
            <input type="text" name="<?php echo $name . '[' . $idx . ']'; ?>" id="<?php echo $name . '[' . $idx . ']'; ?>" class="meta-video regular-text" value="<?php if(isset($meta_value)){ echo $meta_value;}?>"/>
        </div>
        <?php endfor;?>
        
    </div>
    
	<script>
        var inputNumber = document.getElementById("<?php echo $name;?>-input-number");
        inputNumber.onchange = changeInputNumber;

        function changeInputNumber(event){

            var newInputNumber = event.target.value;
            var inputBlock = document.getElementById("<?php echo $name . '_extensible_text'; ?>");

            if(inputBlock.children.length < newInputNumber)
            {
                while (inputBlock.children.length < newInputNumber){
                    var newKey = inputBlock.firstElementChild.cloneNode(true);
                    var newKeyIdx = (parseInt(inputBlock.children.length)).toString();
                    newKey.id = newKey.id.replace("[0]","["+newKeyIdx+"]");
                    var children = newKey.childNodes;

                    for (var childIdx = 0; childIdx < children.length; childIdx++) {
                        if (children[childIdx].htmlFor){children[childIdx].htmlFor = children[childIdx].htmlFor.replace("[0]","["+newKeyIdx+"]");children[childIdx].innerText = children[childIdx].innerText.replace("1",(inputBlock.children.length+1));}
                        if (children[childIdx].id){children[childIdx].id = children[childIdx].id.replace("[0]","["+newKeyIdx+"]");}
                        if (children[childIdx].name){children[childIdx].name = children[childIdx].name.replace("[0]","["+newKeyIdx+"]");}
                        if (children[childIdx].value){children[childIdx].value = "";}
                    }
                    inputBlock.appendChild(newKey);
                }
            
            }else{
                while (inputBlock.children.length > newInputNumber){
                    inputBlock.removeChild(inputBlock.lastElementChild);
                }
            }

            

        }
    </script>    
    <?php
    }
}


class EditorMetaView extends MetaView {

    public static $type = "editor";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data) {
        global $post;
        $settings = array(
            'textarea_name' => $this->name,
            'quicktags'     => array( 'buttons' => 'em,strong,link' ),
            'tinymce'       => array(
                'theme_advanced_buttons1' => 'bold,italic,strikethrough,separator,bullist,numlist,separator,blockquote,separator,justifyleft,justifycenter,justifyright,separator,link,unlink,separator,undo,redo,separator',
                'theme_advanced_buttons2' => '',
            ),
            'editor_css'    => '<style>.wp-editor-area{height:175px; width:100%;}</style>',
        );
        Agent::wp_editor( $this->value, $this->name .'-'. $post->ID, $settings );
    }

}
class ExtensibleKeysMetaView extends MetaView {

    public static $type = "extensible-keys";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data) {
        $value = $this->value;
        $name = $this->name;?>
    <p>
        <label for="<?php echo $name;?>-input-number"><?php ?></label><input id="<?php echo $name;?>-input-number" type=number min=1 value="<?php echo count($value);?>">
    </p>
    <div id="<?php echo $name . '_extensible_keys'; ?>">
        <?php
        for ($idx=0; $idx < count($value); $idx++):
            if (isset($value[$idx])){
                $meta_value = $value[$idx];
            }else{
                $meta_value = "";
            }
        ?>
        <div id="<?php echo $name . '[' . $idx . ']'; ?>">
            <label for="<?php echo $name . '[' . $idx . '][key]'; ?>"><?php echo ($idx+1).'. '; ?></label>
            <input type="text" name="<?php echo $name . '[' . $idx . '][key]'; ?>" id="<?php echo $name . '[' . $idx . '][key]'; ?>" class="meta-video regular-text" value="<?php if(isset($meta_value["key"])){ echo $meta_value["key"];}?>"/>
            <input type="text" name="<?php echo $name . '[' . $idx . '][value]'; ?>" id="<?php echo $name . '[' . $idx . '][value]'; ?>" class="meta-video regular-text" value="<?php if(isset($meta_value["value"])){ echo $meta_value["value"];} ?>"/>
        </div>
        <?php endfor;?>
        
    </div>
    
    <script>
        var inputNumber = document.getElementById("<?php echo $name;?>-input-number");
        inputNumber.onchange = changeInputNumber;

        function changeInputNumber(event){

            var newInputNumber = event.target.value;
            var inputBlock = document.getElementById("<?php echo $name . '_extensible_keys'; ?>");

            if(inputBlock.children.length < newInputNumber)
            {
                while (inputBlock.children.length < newInputNumber){
                    var newKey = inputBlock.firstElementChild.cloneNode(true);
                    var newKeyIdx = (parseInt(inputBlock.children.length)).toString();
                    newKey.id = newKey.id.replace("[0]","["+newKeyIdx+"]");
                    var children = newKey.childNodes;

                    for (var childIdx = 0; childIdx < children.length; childIdx++) {
                        if (children[childIdx].htmlFor){children[childIdx].htmlFor = children[childIdx].htmlFor.replace("[0]","["+newKeyIdx+"]");children[childIdx].innerText = children[childIdx].innerText.replace("1",(inputBlock.children.length+1));}
                        if (children[childIdx].id){children[childIdx].id = children[childIdx].id.replace("[0]","["+newKeyIdx+"]");}
                        if (children[childIdx].name){children[childIdx].name = children[childIdx].name.replace("[0]","["+newKeyIdx+"]");}
                    }
                    inputBlock.appendChild(newKey);
                }
            
            }else{
                while (inputBlock.children.length > newInputNumber){
                    inputBlock.removeChild(inputBlock.lastElementChild);
                }
            }

            

        }
    </script>    
    <?php
    
    }

}