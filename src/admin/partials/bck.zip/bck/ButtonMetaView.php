<?php
Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;
class ButtonMetaView extends MetaView{

    public static $type = "button";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data){
        ?>
        <p>
            <span>Button text:</span> 
            <input type="text" name="<?php echo $this->name; ?>[text]" id="<?php echo $this->name; ?>" class="meta-video regular-text" value="<?php echo $meta['text']; ?>"/>
        </p>
        <p>
            <span>Button link:</span>
            <input 
                type="text" 
                name="<?php echo $this->name; ?>[link]" 
                id="<?php echo $this->name; ?>[link]" 
                class="meta-video regular-text" 
                value="<?php echo $meta['link']; ?>"/>
        </p>
        <?php
    }
}