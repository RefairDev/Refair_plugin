<?php

Namespace PixelscodexPlugin\Metas\Views;

use PixelscodexPlugin\MetaView;
use PixelscodexPlugin\Metas\Utils;

Class ExtensibleMetaView extends MetaView{

    public static $type = "extensible";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view($value,$data){

        if (is_array($value)){
            $value_count = count($value);
        }else{
            $value_count = 1;
        }

        $child_meta = $data['options']['meta'];

        $child_meta_obj = new \ArrayObject($child_meta);
        $child_meta_arr = $child_meta_obj->getArrayCopy();

        ?>
        <p>
            <label for="<?php echo $data['name'];?>-input-number"><?php $data['description']?></label><input id="<?php echo $data['name'];?>-input-number" type=number min=1 value="<?php echo $value_count;?>">
        </p>
        <div id="<?php echo $data['name'] . '_extensible'; ?>">
            <?php
            for ($idx=0; $idx < $value_count; $idx++):
                
                if (isset($value[$idx])){
                    $meta_value = $value[$idx];
                }else{
                    $meta_value = "";
                }
                $child_meta_arr['name'] = $data['name'] ."[".$idx."]";
            ?>
            <div id="<?php echo $data['name']."-".$idx; ?>_block">
                <label for="<?php echo $data['name']."-".$idx; ?>"><?php echo ($idx+1).'. '; ?></label>
                <?php echo apply_filters('rveplugin_renderview_'.$child_meta_arr['type'],$meta_value, $child_meta_arr );?>                
            </div>
            <?php endfor;?>
            
        </div>
        
        <script>
            var inputNumber = document.getElementById("<?php echo $data['name'];?>-input-number");
            inputNumber.onchange = changeInputNumber;
            var newKeyIdx = 0;
    
            function changeInputNumber(event){
    
                var newInputNumber = event.target.value;
                var inputBlock = document.getElementById("<?php echo $data['name'] . '_extensible'; ?>");
    
                if(inputBlock.children.length < newInputNumber)
                {
                    while (inputBlock.children.length < newInputNumber){
                        var newKey = inputBlock.firstElementChild.cloneNode(true);
                        newKeyIdx = (parseInt(inputBlock.children.length)).toString();
                        newKey.id = newKey.id.replace("_0]","_"+newKeyIdx+"]");
                        var children = newKey.childNodes;
    
                        children.forEach(replaceIdx);
                        inputBlock.appendChild(newKey);
                    }
                
                    if (<?php echo $data['name'];?>Script){<?php echo $data['name'];?>Script()};

                }else{
                    while (inputBlock.children.length > newInputNumber){
                        inputBlock.removeChild(inputBlock.lastElementChild);
                    }
                }
    
                
    
            }

            function replaceIdx(currentNode, currentIndex, nodesList){
                attrs = ["htmlFor","id","name","value"];
                attrs.forEach(function(item){
                    if(currentNode[item]){
                        currentNode[item] = currentNode[item].replace("_0]","_"+newKeyIdx+"]");
                        if (item=="htmlFor"){ currentNode.innerText = currentNode.innerText.replace("1",(parseInt(newKeyIdx)+1));}
                    }
                })
                if (currentNode.childNodes.length >0){
                    currentNode.childNodes.forEach(replaceIdx);
                }
            }
        </script>    
        <?php
        
    }
}