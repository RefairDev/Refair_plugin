<?php

Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;
class ArrayMetaView extends MetaView{

    public static $type = "array";
    
    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view( $data, $value){

        if (!is_array($meta)) {
            /* Full fill of the meta with dummy*/
            $dummy_col = array_fill(0, $this->col_n,"");
            $meta = array_fill(0, $this->row_n, $dummy_col);
        }else{
            /* complete rows number*/
            if ($this->row_n >= count($meta)){
                array_merge($meta, array_fill(0, $this->row_n - count($meta), array_fill(0, $this->col_n - 1,"")));
            }
            /* complete col number*/
            for($meta_row_idx = 0; $meta_row_idx < $this->row_n; $meta_row_idx++ ){
                if ($this->col_n >= count($meta[$meta_row_idx])){
                    array_merge($meta[$meta_row_idx], array_fill(0, $this->col_n - count($meta[$meta_row_idx]), ""));
                }
            }
        }
            ?>

        
        <table>
            <thead>
                <tr>
                    <?php 
                        for ($i=0; $i < $this->col_n; $i++):
                            echo '<th>Col #' . ($i+1) . '</th>';
                        endfor;
                    ?>
                </tr>
            </thead>
            <tbody>
                <?php 
                    for ($i=0; $i < $this->row_n; $i++):
                        ?>
                            <tr>
                                <?php 
                                for ($j=0; $j < $this->col_n; $j++):
                                    ?>
                                        <td>
                                            <input 
                                            type="text" 
                                            name="<?php echo "{$this->name}[{$i}][{$j}]"; ?>" 
                                            id="<?php echo "{$this->name}[{$i}][{$j}]"; ?>" 
                                            class="meta-video regular-text" 
                                            value="<?php echo $meta[$i][$j]; ?>"/>
                                        </td>
                                    <?php
                                endfor;
                                ?>
                            </tr>
                        <?php
                    endfor;
                ?>
            </tbody>
        </table>

        <?php
        }
}