<?php
Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;

if(!class_exists('InputMetaView')){
    class InputMetaView extends MetaView{

        public function __construct(
            $options = array()
        ) {
            parent::__construct(
            $options = array());
        }

        public function set_type($type){
            $this->input_type = $type;
        }

        public function set_value($value){
            $this->value = $value;
        }

        public function get_view($value,$data){
            
            $viewcontent ='<p>
                <input type="'. $this->input_type.'" name="' . $data["name"] .'" id="'.$data["name"].'" class="meta-video regular-text" value="'.$value.'"/>
            </p>';
            return $viewcontent;
        }
    }
}