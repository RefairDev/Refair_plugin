<?php
Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;
class CheckboxMetaView extends MetaView{

    public static $type = "checkbox";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function get_view( $data, $value){
        ?>
        <label for="<?php echo $this->name; ?>"><?php echo $this->description; ?></label>

        <p><?php
            foreach ($this->choices as $choice) {
                if (is_array($choice)) {
                    $value = $choice['value'];
                    $name = $choice['name'];
                } else {
                    $value = $choice->value;
                    $name = $choice->name;
                }
                ?>
                <label for="<?php echo $this->name . '-' . $value ; ?>">
                    <input 
                        type="checkbox" 
                        name="<?php echo $this->name; ?>[]"
                        id="<?php echo $this->name . '-' . $value ; ?>"
                        value="<?php echo $value ?>"
                        <?php if ( is_array($meta) && in_array($value, $meta)): ?>
                            checked
                        <?php endif ?>
                        />
                    <?php echo $name; ?>
                </label>
                <?php
            }?>
        </p>
        <?php
    }
}