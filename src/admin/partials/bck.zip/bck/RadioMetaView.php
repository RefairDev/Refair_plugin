<?php
Namespace PixelscodexPlugin\Metas\Views;
use PixelscodexPlugin\MetaView;

class RadioMetaView extends MetaView{

    public static $type ="radio";

    public function __construct(
        $options = array()
    ) {
        parent::__construct(
        $options = array());
    }

    public function set_type($type){
        $this->type = $type;
    }

    public function set_value($value){
        $this->value = $value;
    }

    public function get_view($value,$data){
        ?>
        <p><?php
            foreach ($this->choices as $choice) {
                if (is_array($choice)) {
                    $value = $choice['value'];
                    $name = $choice['name'];
                } else {
                    $value = $choice->value;
                    $name = $choice->name;
                }
                ?>
                <label for="<?php echo $this->name . '-' . $value ; ?>">
                    <input 
                        type="radio" 
                        name="<?php echo $this->name; ?>"
                        id="<?php echo $this->name . '-' . $value ; ?>"
                        value="<?php echo $value ?>"
                        <?php if ( $meta == $value): ?>
                            checked
                        <?php endif ?>
                        />
                    <?php echo $name; ?>
                </label>
                <?php
            }?>
        </p>
        <?php
    }
}
